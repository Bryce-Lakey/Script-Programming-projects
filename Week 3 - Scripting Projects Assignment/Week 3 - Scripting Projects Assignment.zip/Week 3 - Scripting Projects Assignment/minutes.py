years = int(input("Enter the amount of years: "))
days = years * 365
hours = days * 24
minutes = hours * 60

print("The amount of minutes in that time period is: ", minutes)
