for count in range(1,4):
    print(count)
