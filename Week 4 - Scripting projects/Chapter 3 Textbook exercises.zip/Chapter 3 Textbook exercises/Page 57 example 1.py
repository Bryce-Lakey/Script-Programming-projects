for number in [6, 4, 8]:
    print(number, end = " ")

for character in "Hi there!":
    print(character, end = " ")
