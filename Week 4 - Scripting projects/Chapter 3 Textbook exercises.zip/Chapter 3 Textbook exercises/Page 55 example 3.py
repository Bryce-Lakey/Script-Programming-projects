product = 1
for count in range (1, 5):
    product = product * count
    
