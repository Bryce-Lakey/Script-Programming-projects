theSum = 0
for count in range(2, 11, 2):
    theSum += count

print(theSum)
