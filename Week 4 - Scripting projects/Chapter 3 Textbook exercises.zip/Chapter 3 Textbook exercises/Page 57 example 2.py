list (range(1,6,1))
list (range(1,6,2))
list (range(1,6,3))
