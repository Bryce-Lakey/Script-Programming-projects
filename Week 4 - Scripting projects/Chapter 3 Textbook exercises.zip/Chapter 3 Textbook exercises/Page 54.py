for eachPass in range(4):
    print ("It's alive!", end = " ")
