for exponent in range(7, 11):
    print ("%-3d%12d" % (exponent, 10 ** exponent))
    
