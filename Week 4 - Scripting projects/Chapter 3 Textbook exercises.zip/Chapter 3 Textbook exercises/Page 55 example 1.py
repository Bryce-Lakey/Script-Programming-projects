for count in range(4):
    print (count, end = " ")
