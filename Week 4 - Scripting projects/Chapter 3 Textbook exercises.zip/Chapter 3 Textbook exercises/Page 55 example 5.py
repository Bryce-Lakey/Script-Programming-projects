list(range(4))
list(range(1, 5))
