for exponent in range(7,11):
    print(exponent, 10 ** exponent)
