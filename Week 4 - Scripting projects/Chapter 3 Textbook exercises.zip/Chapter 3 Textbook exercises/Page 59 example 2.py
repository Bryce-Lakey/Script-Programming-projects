"%6s" % "four"
"%-6s" % "four"
