for count in range(10, 0, -1):
    print(count, end = " ")

list(range(10, 0, -1))
