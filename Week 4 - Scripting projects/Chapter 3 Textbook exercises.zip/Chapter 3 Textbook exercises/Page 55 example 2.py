product = 1
for count in range (4):
    product = product * (count + 1)
