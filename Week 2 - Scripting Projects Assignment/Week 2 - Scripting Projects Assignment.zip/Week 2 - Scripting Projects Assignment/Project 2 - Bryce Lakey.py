edgeLength = input("The width of the cube is 44in. Enter the length of an edge: ")
edgeLength = int(edgeLength)
area = edgeLength * 44
print(area)
