firstName = "Bryce"
secondName = "Lakey"
fullName = firstName + " " + secondName
print(fullName)
