mass = input("Enter the mass of an object (kg): ")
mass = int(mass)
velocity = input ("Enter the velocity of the object (m/sec): ")
velocity = int(velocity)
momentum = mass * velocity
print("The momentum of the object is: ", momentum, "N s")

"""

The N s in the print line is indicating Newton Seconds, which is a unit
that momentum is typically represented in. I just wanted some sort of unit to
make it look proper.

"""
