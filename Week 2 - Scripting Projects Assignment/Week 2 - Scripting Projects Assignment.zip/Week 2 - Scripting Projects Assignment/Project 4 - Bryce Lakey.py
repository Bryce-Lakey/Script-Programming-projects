radius = input("Enter the sphere's radius: ")
radius = float(radius)
diameter = 2 * radius
circumfrence = 2 * 3.14 * radius
surfaceArea = 4 * 3.14 * radius**2
volume = (4/3)*3.14 * radius**3
print ("The diameter is: ", diameter,
       "\nThe circumfrence is: ", circumfrence,
       "\nThe surfaceArea is: ", surfaceArea,
       "\nThe volume is: ", volume)
