height = int(input("Enter height here: "))
width = int(input("Enter width here: "))
depth = int(input("Enter depth here: "))
volume = height * width * depth
print("The volume of a cuboid is: ", volume, "cubic units")
