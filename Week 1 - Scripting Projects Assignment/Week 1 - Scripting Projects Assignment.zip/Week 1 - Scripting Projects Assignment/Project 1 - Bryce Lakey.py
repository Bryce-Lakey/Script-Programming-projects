name = "Bryce Lakey. Muskogee, OK. 918-123-456."
print(name)
