length = int(input("Enter length here: "))
height = int(input("Enter height here: "))
area = length * height
print("The area is: ", area)
