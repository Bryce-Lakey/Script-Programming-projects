base = int(input("Enter base here: "))
height = int(input("Enter height here: "))
tri_area = .5 * base * height
print("The area of a triangle is: ", tri_area)
