radius = float(input("Enter radius here: "))
cir_area = 3.14 * radius ** 2
print("The area of a circle is: ", cir_area)
